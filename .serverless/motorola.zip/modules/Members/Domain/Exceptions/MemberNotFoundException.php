<?php

namespace Motorola\Members\Domain\Exceptions;

use Exception;

class MemberNotFoundException extends Exception {}
