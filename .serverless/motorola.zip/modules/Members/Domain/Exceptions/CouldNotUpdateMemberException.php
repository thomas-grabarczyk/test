<?php

namespace Motorola\Members\Domain\Exceptions;

use Exception;

class CouldNotUpdateMemberException extends Exception {}
