<?php

namespace Motorola\Members\Domain\Exceptions;

use Exception;

class CouldNotDeleteMemberException extends Exception {}
