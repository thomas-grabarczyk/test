<?php

namespace Motorola\Members\Domain\Exceptions;

use Exception;

class CouldNotCreateMemberException extends Exception {}
