1. Clone repo


2. Composer install


3. Run `./vendor/bin/sail up -d`


4. Run `./vendor/bin/sail php artisan db:seed --class=Motorola\\Members\\Infrastructure\\Database\\MySQL\\Seeders\\MembersSeeder`


5 Run `./vendor/bin/sail php artisan db:seed` to seed admin user. Email: admin@mail.com, Password: password


